extends Node2D

#Array used to get filled with PackedScene objects so they can be instantiated into Node2D and assigned to
 #different array
var arr: Array[PackedScene]

#Packed scene used to instantiate the units
@onready var p_infantry = preload("res://player_units/player_infantry.tscn")
@onready var p_archer = preload("res://player_units/player_archer.tscn")
@onready var p_cav = preload("res://player_units/player_cav.tscn")
@onready var p_leader = preload("res://player_units/player_leader.tscn")

@onready var e_infantry = preload("res://enemies/enem_infantry.tscn")
@onready var e_archer = preload("res://enemies/enem_archer.tscn")
@onready var e_cav = preload("res://enemies/enem_cav.tscn")
@onready var e_leader = preload("res://enemies/enem_leader.tscn")

var world

#Instantiated/final array that will be used outside this node
var fin_arr: Array[Node2D]

func _ready():
	world = get_tree().get_first_node_in_group("World")

#Returns array of units instanced as Node2D so their attributes can be accessed
func p_instances(infantry_fin: Array[PackedScene]) -> Array[Node2D]:
	var inf_arr: Array[Node2D] = []
	for i in infantry_fin:
		var a = i.instantiate()
		add_child(a)
		a.add_to_group("infantry")
		world.units.append(a)
		a.visible = false
		a.position.x = -100000
		inf_arr.append(a)
	return inf_arr

func e_instances(infantry_fin: Array[PackedScene]) -> Array[Node2D]:
	var inf_arr: Array[Node2D] = []
	for i in infantry_fin:
		var a = i.instantiate()
		add_child(a)
		a.add_to_group("infantry")
		world.enem_units.append(a)
		a.visible = false
		inf_arr.append(a)
	return inf_arr


func p_check(type: int) -> void:
	if type == 1:
		arr.resize(30)
		arr.fill(p_infantry)
		fin_arr.assign(p_instances(arr))
	if type == 2:
		arr.resize(16)
		arr.fill(p_archer)
		fin_arr.assign(p_instances(arr))
	if type == 3:
		arr.resize(8)
		arr.fill(p_cav)
		fin_arr.assign(p_instances(arr))
	if type == 4:
		arr.resize(1)
		arr.fill(p_leader)
		fin_arr.assign(p_instances(arr))

func e_check(type: int) -> void:
	if type == 1:
		arr.resize(30)
		arr.fill(e_infantry)
		fin_arr.assign(e_instances(arr))
	if type == 2:
		arr.resize(16)
		arr.fill(e_archer)
		fin_arr.assign(e_instances(arr))
	if type == 3:
		arr.resize(8)
		arr.fill(e_cav)
		fin_arr.assign(e_instances(arr))
	if type == 4:
		arr.resize(1)
		arr.fill(e_leader)
		fin_arr.assign(e_instances(arr))
