extends Control

var chosen: bool = false
var player_stats: Node2D
var camera: CanvasItem
var area: Area2D
var spawn_zone: Area2D
@onready var sprite = $Sprite2D as Sprite2D

func _ready():
	player_stats = get_tree().get_first_node_in_group("player_stats")
	camera = get_tree().get_first_node_in_group("camera")
	spawn_zone = get_tree().get_first_node_in_group("spawn_zone")
	sprite.scale.x = 0.5
	sprite.scale.y = 0.5

#Method for all the inputs needed to spawn a group
func _input(_event) -> void:
	if Input.is_action_just_pressed("LMB") and chosen == true:
		chosen = !chosen
		player_stats.dictAB.find_key(player_stats.dictPA[self]).visible = true
		Glb.spawned_squads += 1

#Main method for following the players mouse to indicate spawn location
func _physics_process(_delta) -> void:
	pause_check()
	if chosen == true:
		Formation.selection_spawn_formation(camera.get_global_mouse_position(), player_stats.dictPA[self].fin_arr)

#Method used to check wheather the game is paused
func pause_check():
	sprite_check()
	if Glb.curr_game_state == Glb.game_state.PAUSED:
		self.visible = false
	if Glb.curr_game_state != Glb.game_state.PAUSED:
		self.visible = true

func sprite_check():
	if player_stats.dictPA[self].fin_arr[0] is player_infantry:
		sprite.texture = preload("res://p_inf_charbox.png")
	if player_stats.dictPA[self].fin_arr[0] is player_archer:
		sprite.texture = preload("res://p_arch_charbox.png")
	if player_stats.dictPA[self].fin_arr[0] is player_cav:
		sprite.texture = preload("res://p_cav_charbox.png")
	if player_stats.dictPA[self].fin_arr[0] is player_leader:
		sprite.texture = preload("res://p_lead_charbox.png")


func _on_area_2d_input_event(viewport, event, shape_idx):
	if Input.is_action_just_pressed("LMB"):
		chosen = !chosen
