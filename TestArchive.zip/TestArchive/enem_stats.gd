extends Node2D

var allUnits: Array[Node2D]
@onready var infantry: PackedScene = preload("res://infantry.tscn")
@onready var banner: PackedScene = preload("res://enem_banner.tscn")
var inf_name: int = 80
var values_arr: Array = [1, 1, 1, 1, 1, 2, 2, 3, 3, 4]

var pos: int = 0
var Name: int = 0

@export var dictAB: Dictionary

func _ready():
	allUnits.resize(0)
	instances(values_arr, allUnits)
	banners(allUnits)

#instantiates banners which act as a representation of each array of units on the field itself
func banners(allUnits_arr: Array) -> void:
	for i in allUnits_arr:
		var a = banner.instantiate()
		add_child(a)
		Name += 1
		a.name = str(Name)
		a.position.x = pos
		dictAB[a] = i

#instantiating the packed scenes as nodes so their scripts can be accessed
func instances(values_arr: Array, allUnits_arr: Array) -> void:
	for n in values_arr:
		var u = infantry.instantiate()
		add_child(u)
		inf_name += 1
		u.name = str(inf_name)
		u.e_check(n)
		allUnits.append(u)
	allUnits.resize(10)
