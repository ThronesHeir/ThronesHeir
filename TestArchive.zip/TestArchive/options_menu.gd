extends Control

var resolutions = {
	"3840x2160": Vector2i(3840,2160),
	"2560x1440": Vector2i(2560,1440),
	"1920x1080": Vector2i(1920,1080),
	"1366x768": Vector2i(1366,768),
	"1280x720": Vector2i(1280,720),
	"1440x900": Vector2i(1440,900),
	"1600x900": Vector2i(1600,900),
	"1152x648": Vector2i(1152,648),
	"1024x600": Vector2i(1024,600),
	"800x600": Vector2i(800,600)
}

@onready var resolutions_button = $HBoxContainer/VBoxContainer/OptionButton

func _ready():
	add_resolutions()

func add_resolutions():
	for i in resolutions:
		resolutions_button.add_item(i)

func update_button_settings():
	var window_size_string = str(get_window().size.x, "x", get_window().size.y)
	var resolutions_index = resolutions.keys().find(window_size_string)
	resolutions_button.selected = resolutions_index

func _on_option_button_item_selected(index):
	var key = resolutions_button.get_item_text(index)
	get_window().set_size(resolutions[key])
	center_window()

func center_window():
	var screen_center = DisplayServer.screen_get_position() + DisplayServer.screen_get_size() / 2
	var window_size = get_window().get_size_with_decorations()
	get_window().position =  screen_center - window_size / 2


func _on_button_gui_input(event):
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		self.visible = false 
		self.set_process_input(false)
		if Glb.curr_game_state != Glb.game_state.BEGGINING:
			Glb.battle()
