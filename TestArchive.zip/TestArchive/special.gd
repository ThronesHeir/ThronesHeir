extends Area2D

@onready var area: PackedScene = preload("res://sp_attack_area.tscn")
var sp_attack_area
var world
var camera: CanvasItem
var following: bool = false
signal sp_atk

func _ready():
	camera = get_tree().get_first_node_in_group("camera")
	sp_attack_area = get_tree().get_first_node_in_group("sp_attack_area")
	connect("sp_atk", Callable(sp_attack_area, "sp_atk"))

func _process(_delta):
	if following == true:
		sp_attack_area.position = camera.get_global_mouse_position()

func _on_input_event(viewport, event: InputEvent, shape_idx):
	if Input.is_action_just_pressed("LMB"):
		sp_attack_area.visible = true
		following = true

func _input(event: InputEvent):
	if Input.is_action_just_pressed("LMB") and following == true:
		following = false
		emit_signal("sp_atk")
		sp_attack_area.sprite.visible = true
		sp_attack_area.anim.play("sp_atk")
		self.set_process(false)
