extends Node2D


var allUnits: Array[Node2D]
@onready var infantry: PackedScene = preload("res://infantry.tscn")
@onready var panel: PackedScene = preload("res://spawn_panel.tscn")
@onready var banner: PackedScene = preload("res://banner.tscn")
var UI: CanvasLayer
var inf_name: int = 0
var values_arr: Array = [1, 1, 1, 1, 1, 2, 2, 3, 3, 4]

var pos_x: int = 0
var pos_y: int = 530
var Name: int = 0

@export var dictPA: Dictionary
@export var dictAB: Dictionary


func _ready():
	UI = get_tree().get_first_node_in_group("UI")
	allUnits.resize(0)
	instances(values_arr, allUnits)
	panels(allUnits)
	banners(allUnits)

#instantiating panels that act as a visual representation for army squads before they
 #are created and connecting them to the groups of units they represent
func panels(allUnits_arr: Array) -> void:
	for i in allUnits_arr:
		var a = panel.instantiate()
		UI.add_child(a)
		pos_x += 100
		Name += 1
		a.name = str(Name)
		a.position = Vector2(pos_x, pos_y)
		dictPA[a] = i

#instantiates banners which act as a representation of each array of units on the field itself
func banners(allUnits_arr: Array) -> void:
	for i in allUnits_arr:
		var a = banner.instantiate()
		add_child(a)
		Name += 1
		a.name = str(Name)
		a.position.x = pos_x
		dictAB[a] = i

#instantiating the packed scenes as nodes so their scripts can be accessed
func instances(values_arr:Array, allUnits_arr: Array) -> void:
	for n in values_arr:
		var u = infantry.instantiate()
		add_child(u)
		inf_name += 1
		u.name = str(inf_name)
		u.p_check(n)
		allUnits.append(u)
	allUnits.resize(10)
