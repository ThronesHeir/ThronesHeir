extends Node

var all_spawn_p: Array
var enem_stats: Node2D

#Called when the node enters the scene tree for the first time.
func _ready():
	all_spawn_p = self.get_children()
	enem_stats = get_tree().get_first_node_in_group("enem_stats")
	get_all_enem()


func get_all_enem():
	var i: int = 0
	for u in enem_stats.allUnits:
		Formation.selection_spawn_formation_arr(all_spawn_p[i].position, u.fin_arr)
		i += 1
