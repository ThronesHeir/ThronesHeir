class_name enem_cav
extends enem_unit
