class_name enem_infantry
extends enem_unit

