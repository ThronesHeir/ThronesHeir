class_name enem_unit
extends CharacterBody2D

#Variables needed for basic operations like enemy detection and movement
@export var selected = false
@export var u_class: String
@onready var nav_agent := $NavigationAgent2D as NavigationAgent2D
@onready var target = position
@onready var area_detection = $Area2D as Area2D
@onready var anim = $AnimationPlayer as AnimationPlayer
@onready var sprite = $Sprite2D as Sprite2D
var player_target: player_unit = null

#Variables related to the units stats
@export var atk: float = 10
@export var speed: int = 100
@export var hp: float = 100

#All signals used in the state machine
signal E_Attack
signal E_Walk
signal E_Idle
signal E_Dead

var curr_state
enum state {
	IDLE,
	ATTACK,
	WALKING,
	DEAD
}

#Method called upon the nodes entrance in the scene
func _ready():
	self.set_process(false)
	curr_state = state.IDLE
	target = null
	connect("E_Attack", Callable(self, "switch_to_atk"))
	connect("E_Walk", Callable(self, "switch_to_walk"))
	connect("E_Dead", Callable(self, "switch_to_dead"))
	connect("E_Idle", Callable(self, "switch_to_idle"))


#Main loop used for the main action method related to the state machine
func _physics_process(_delta):
	flip_check()
	action()

#Main action method where all the states get assigned the actions needed to be performed
func action() -> void:
	if curr_state == state.IDLE:
		anim_idle()
		idle()
		body_detection()
	if curr_state == state.WALKING:
		anim_walk()
		movement()
		body_detection()
	if curr_state == state.ATTACK:
		anim_atk()
		attack()
		movement()
		body_detection()
	if curr_state == state.DEAD:
		death()

#Method using the move_and_slide method and the navigation agent to make the unit move to the target position
func movement() -> void:
		nav_agent.target_position = target
		var next_pos = nav_agent.get_next_path_position()
		var dir = global_position.direction_to(next_pos) * speed
		if hp <= 0:
			emit_signal("E_Dead")
		elif nav_agent.is_target_reached() == false and nav_agent.target_position != null:
			velocity = dir
			move_and_slide()
		elif nav_agent.is_target_reached() and player_target == null:
			target = null
			emit_signal("E_Idle")

#Method used upon the units defeat (hp falling to zero or below)
func death() -> void:
	self.visible = false
	self.set_collision_layer_value(1, false)
	self.rotation_degrees = 90
	self.set_process(false)
	self.set_physics_process(false)
	player_target = null
	target = null

#The first method used upon entry since it's the base state assigned in the ready method
func idle() -> void:
	if hp <= 0:
		emit_signal("E_Dead")
	elif target != null and player_target != null:
		emit_signal("E_Attack")
	elif target != null and player_target == null:
		emit_signal("E_Walk")

#Method called upon the variable player_target gaining any value other than null 
func attack() -> void:
	if hp <= 0:
		emit_signal("Е_Dead")
	elif player_target != null:
		if player_target.hp > 0:
			player_target.hp -= atk
		if player_target.hp <= 0:
			player_target = null
			emit_signal("E_Idle")
	else: emit_signal("E_Idle")

func flip_check():
	if target != null:
		if target.x < self.position.x:
			sprite.flip_h = true
		else:
			sprite.flip_h = false

#Method used in almost every state so the enemy can determine a target
func body_detection() -> void:
	if player_target == null:
		for u in area_detection.get_overlapping_bodies():
			if u is player_unit:
				target = u.position
				player_target = u
				emit_signal("E_Attack")
				return

func damage_done():
	if player_target.hp > 0:
		player_target.hp -= atk

#Methods relating to the state switches invoked upon the emission of the connected signal in the ready method 
func switch_to_atk() -> void:
	curr_state = state.ATTACK

func switch_to_idle() -> void:
	curr_state = state.IDLE

func switch_to_walk() -> void:
	curr_state = state.WALKING

func switch_to_dead() -> void:
	curr_state = state.DEAD

func anim_idle():
		if anim.is_playing() and anim.current_animation == "e_" + u_class + "_idle":
			pass
		elif anim.is_playing() == false and anim.current_animation != "e_" + u_class + "_idle":
			anim.play("e_" + u_class + "_idle")
		elif anim.is_playing() == false:
			anim.play("e_" + u_class + "_idle")

func anim_atk():
		if anim.is_playing() and anim.current_animation == "e_" + u_class + "_atk":
			pass
		elif anim.is_playing() == false and anim.current_animation != "e_" + u_class + "_atk":
			anim.play("e_" + u_class + "_atk")
		elif anim.is_playing() == false:
			anim.play("e_" + u_class + "_atk")

func anim_walk():
		if anim.is_playing() and anim.current_animation == "e_" + u_class + "_walk":
			pass
		elif anim.is_playing() == false and anim.current_animation != "e_" + u_class + "_walk":
			anim.play("e_" + u_class + "_walk")
		elif anim.is_playing() == false:
			anim.play("e_" + u_class + "_walk")

func _on_animation_player_animation_finished(anim_name):
	if anim_name == "e_" + u_class + "atk":
		damage_done()
