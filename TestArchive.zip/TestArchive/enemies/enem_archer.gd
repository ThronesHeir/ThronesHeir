class_name enem_archer
extends enem_unit

