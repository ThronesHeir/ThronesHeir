extends Node

#basics formation parameters
var formation_divisor: int = 5:
	set(new_val): formation_divisor = clampi(new_val, 3, 15)
var formation_spread: float = 35.0:
	set(new_val): formation_spread = clampi(new_val, 0.5, 40.0)
var formation_rotation: float = 0.0


# Used for calculating target formation positions for an array of units which will move to the position
static func formation_positions(
	formation_destionation: Vector2,
	formation_units: Array,
	formation_parameters = [3, 1.0, 0.0]
) -> PackedVector2Array:
	
	#parameters getting instantiated as variables for easier use
	var formation_size: int = (formation_units.size() as int)
	var formation_divisor: int = (formation_parameters[0] as int)
	var formation_spread: float = (formation_parameters[1] as int)
	
	var current_units_pos: Array[Vector2] = []
	for unit: Node2D in formation_units:
		current_units_pos.append(Vector2(unit.global_position.x, unit.global_position.y))
	
	#variables needed to adjust the spread(space between units in formation) 
	#and divisor(number of rows in formation)
	var divisor: int = formation_divisor
	var horizontal_size: int = ceili(float(formation_size) / divisor)
	var vertical_size: int = divisor
	var spread: float = formation_spread
	
	#final variables that are used in the main loop of the method
	var formation_pos: Array[Vector2] = []
	var Hi: int = 0
	var Vi: int = 0
	
	#main loop of the method in which the final positions of the formation are calculated using earlier vars
	for unit in formation_units:
		var H_swapper: int = 1
		while Vi < vertical_size:
			while Hi < horizontal_size:
				H_swapper *= -1
				var formation_position: Vector2 = Vector2((spread * Hi) * H_swapper, spread * Vi)
				formation_pos.append(formation_destionation + (formation_position).rotated(formation_parameters[2])) 
				Hi += 1
			Vi += 1
			Hi = 0
	return formation_pos as PackedVector2Array

#used for spawning units directly into the needed formation
static func formation_positions_spawn(
	formation_destionation: Vector2,
	formation_units: Array,
	formation_parameters = [3, 1.0, 0.0],
) -> PackedVector2Array:
	
	var formation_size: int = (formation_units.size() as int)
	var formation_divisor: int = (formation_parameters[0] as int)
	var formation_spread: float = (formation_parameters[1] as int)
	
	var current_units_pos: Array[Vector2] = []
	for unit:Node2D in formation_units:
		current_units_pos.append(Vector2(unit.global_position.x, unit.global_position.y))
	var current_unit_pos_center: Vector2 = get_avrg_pos(current_units_pos)
	
	var divisor: int = formation_divisor
	var horizontal_size: int = ceili(float(formation_size) / divisor)
	var vertical_size: int = divisor
	var spread: float = formation_spread
	
	var formation_pos: Array[Vector2] = []
	var Hi: int = 0
	var Vi: int = 0
	
	for unit in formation_units:
		var H_swapper: int = 1
		while Vi < vertical_size:
			while Hi < horizontal_size:
				H_swapper *= -1
				var formation_position: Vector2 = Vector2((spread * Hi) * H_swapper, spread * Vi)
				formation_pos.append(formation_destionation + (formation_position).rotated(formation_parameters[2]))
				Hi += 1
			Vi += 1
			Hi = 0
	return formation_pos as PackedVector2Array

static func get_avrg_pos(from_vecs2: Array[Vector2]) -> Vector2:
	var summed_vec2: Vector2 = Vector2()
	for vec2pos in from_vecs2: summed_vec2 += vec2pos
	return (summed_vec2 / from_vecs2.size() as Vector2).snapped(Vector2(0.01, 0.01))

static func units_to_vec2(units: Array[Node2D]) -> Array[Vector2]:
	var arr_vec2: Array[Vector2]
	for unit: Node2D in units:
		arr_vec2.append(Vector2(unit.global_position.x, unit.global_position.y))
	return arr_vec2

static func selection_movement_formation(where_to: Vector2, selected_units: Array[Node2D]) -> void:
		var formation_positions: PackedVector2Array = Formation.formation_positions(where_to, selected_units,
		[Formation.formation_divisor, Formation.formation_spread, Formation.formation_rotation])
		var i: int = 0
		for unit in selected_units:
			var pos: Vector2 = Vector2(formation_positions[i].x, formation_positions[i].y)
			unit.target = pos
			unit.switch_to_walk()
			i += 1

static func selection_spawn_formation(where_to:Vector2, selected_units: Array[Node2D]) -> void:
	var formation_positions: PackedVector2Array = Formation.formation_positions_spawn(where_to, selected_units,
	[Formation.formation_divisor, Formation.formation_spread, Formation.formation_rotation])
	var i: int = 0
	for unit in selected_units:
		var pos: Vector2 = Vector2(formation_positions[i].x, formation_positions[i].y)
		unit.position = pos
		unit.visible = true
		unit.curr_state = unit.state.IDLE
		unit.target = null
		unit.set_process(true)
		i += 1

static func selection_spawn_formation_arr(where_to:Vector2, selected_units: Array[Node2D]) -> void:
	var formation_positions: PackedVector2Array = Formation.formation_positions_spawn(where_to, selected_units,
	[Formation.formation_divisor, Formation.formation_spread, Formation.formation_rotation])
	var i: int = 0
	for unit in selected_units:
		var pos: Vector2 = Vector2(formation_positions[i].x, formation_positions[i].y)
		unit.set_process(true)
		unit.position = pos
		unit.visible = true
		i += 1
