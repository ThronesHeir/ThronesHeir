extends Node

var curr_game_state
var world
var spawned_squads = 0

enum game_state {
	BEGGINING,
	BATTLE,
	PAUSED
}

func beggining():
	world = get_tree().get_first_node_in_group("World")
	curr_game_state = game_state.BEGGINING
	for u in world.units:
		u.set_physics_process(false)
	for u in world.enem_units:
		u.target = null
		u.set_physics_process(false)

func battle():
	world = get_tree().get_first_node_in_group("World")
	curr_game_state = game_state.BATTLE
	for u in world.units:
		u.set_physics_process(true)
	for u in world.enem_units:
		u.set_physics_process(true)

func pause():
	world = get_tree().get_first_node_in_group("World")
	curr_game_state = game_state.PAUSED
	for u in world.units:
		u.set_physics_process(false)
	for u in world.enem_units:
		u.set_physics_process(false)
