extends Control

func _on_panel_gui_input(event):
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		get_tree().change_scene_to_packed(load("res://level_1.tscn"))



func _on_panel_2_gui_input(event):
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		get_tree().change_scene_to_packed(load("res://level_2.tscn"))
