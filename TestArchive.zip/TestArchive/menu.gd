extends Control

func _ready():
	$AnimatedSprite2D/AnimationPlayer.play("intro")

func _on_start_pressed():
	get_tree().change_scene_to_file("res://tutorial.tscn")
	

func _on_quit_pressed():
	get_tree().quit()

func _on_animation_player_animation_finished(anim_name):
	if anim_name == "intro":
		$AnimatedSprite2D/AnimationPlayer.stop()
		$AnimatedSprite2D/AnimationPlayer.seek(0.5, true)
		get_node("Start2").visible = true
		get_node("Quit2").visible = true
		get_node("Start").visible = true
		get_node("Quit").visible = true
