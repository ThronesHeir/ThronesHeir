extends Node2D

@onready var units: Array
@onready var enem_units: Array
var enem_stats
var player_stats
@onready var target = position
@onready var selected = false
@onready var camera = get_node("Camera2D")
@onready var arrow: PackedScene = preload("res://arrow.tscn")
@onready var options = $UI/options_menu as Control
@onready var timer = $Timer as Timer
@onready var button = $UI/Button as Button
@onready var sprite = $UI/Button/Sprite2D as Sprite2D
var followCursor = false
var arrow_arr: Array[Node2D]

var x: float = 1:
	set(new_val): x = clampf(new_val, 0.6, 2.0)
var y: float = 1:
	set(new_val): y = clampf(new_val, 0.6, 2.0)

func _ready():
	enem_stats = get_tree().get_first_node_in_group("enem_stats")
	player_stats = get_tree().get_first_node_in_group("player_stats")
	Glb.beggining()
	fin_pos_e()

func _physics_process(_delta):
	var temp_units = find_selected_units()
	if temp_units.is_empty() == false:
		Formation.selection_spawn_formation_arr(get_global_mouse_position(), arrow_arr)

#Setting first target position to global mouse position
func _input(event) -> void:
	if event.is_action_pressed("RMB"):
		followCursor = true
		target = get_global_mouse_position()
		Formation.selection_movement_formation(target, find_selected_units())
	if event.is_action_released("RMB"):
		followCursor = false
	
	if event.is_action_pressed("Menu"):
		$UI/esc_menu.visible = true
		if Glb.curr_game_state != Glb.game_state.BEGGINING:
			Glb.pause()
		for u in units:
			u.set_physics_process(false)
		for u in enem_units:
			u.set_physics_process(false)
	
	if event.is_action_pressed("LMB"):
		unselect(find_selected_units())
	
	if event.is_action_pressed("ZoomIn"):
		x += 0.1
		y += 0.1
		camera.zoom = Vector2(x, y)
	if event.is_action_pressed("ZoomOut"):
		x -= 0.1
		y -= 0.1
		camera.zoom = Vector2(x, y)
	
	if event is InputEventMouseMotion:
		if event.button_mask == MOUSE_BUTTON_MASK_MIDDLE:
			camera.position -= event.relative
	
	if Input.is_action_pressed("RotationQ"):
		Formation.formation_rotation -= 0.1
	if Input.is_action_pressed("RotationE"):
		Formation.formation_rotation += 0.1
	if Input.is_action_just_pressed("DownArrow"):
		Formation.formation_divisor -= 1
	if Input.is_action_just_pressed("UpArrow"):
		Formation.formation_divisor += 1
	
	if Input.is_action_pressed("Pause"):
		if Glb.curr_game_state == Glb.game_state.BATTLE:
			Glb.pause()
		elif Glb.curr_game_state == Glb.game_state.PAUSED:
			Glb.battle()
			fin_pos_e()

#Selection method
func on_area_selection(object) -> void:
		var start = object.Start
		var end = object.End
		var area = []
		area.append(Vector2(min(start.x, end.x), min(start.y, end.y)))
		area.append(Vector2(max(start.x, end.x), max(start.y, end.y)))
		var ut = get_units(area)
		for u in units:
			u.set_selected(false)
		for u in ut:
			if u.hp > 0:
				u.set_selected(!u.selected)

#Method for finding out which units are in the drawn area
func get_units(area) -> Array:
	var u = []
	for unit in units:
		if unit.position.x > area[0].x and unit.position.x < area[1].x:
			if unit.position.y > area[0].y and unit.position.y < area[1].y:
				u.append(unit)
	return u

#Finds selected units and returns an array containing them
func find_selected_units() -> Array[Node2D]:
	var selected_units: Array[Node2D] = []
	for u in units:
		if u.selected == true and u.hp > 0:
			selected_units.append(u)
	return selected_units

#Method for creating arrows showing where friendly units will be placed
func arrow_up() -> void:
	var i = arrow.instantiate()
	add_child(i)
	arrow_arr.append(i)

#Method to set the selected variable of an array of units to false used to quickly unselect many units with the RMB button
func unselect(selected_units: Array[Node2D]) -> void:
	for u: player_unit in selected_units:
		u.set_selected(false)

#Method for erasing the arrows
func arrow_down() -> void:
	if arrow_arr.is_empty() == false:
		var n = arrow_arr.find(arrow)
		arrow_arr.pop_at(n).queue_free()


func _on_button_gui_input(event: InputEvent) -> void:
	if event.is_action_pressed("LMB") and check_all_units() == true:
		button.queue_free()
		timer.start()
		Glb.battle()
		timer.autostart = true
		fin_pos_e()
		button.set_process_input(false)
		sprite.visible = false

func fin_pos_e() -> void:
	for u in enem_stats.allUnits:
		get_positions_enem_units(u.fin_arr)

func get_positions_enem_units(ene: Array) -> void:
	var i = 0
	var enems: Array[Node2D]
	var get_dist = position
	for u in ene:
		if u.player_target == null:
			enems.append(u)
	var init_unit: player_unit = units[0]
	for u: player_unit in units:
		if init_unit.position.distance_to(Formation.get_avrg_pos(Formation.units_to_vec2(enems))) > u.position.distance_to(Formation.get_avrg_pos(Formation.units_to_vec2(enems))) and u.hp > 0:
			init_unit = u
	Formation.selection_movement_formation(init_unit.position, enems)

func check_all_units() -> bool:
	for u in player_stats.allUnits:
		for i in u.fin_arr:
			if i.visible == false:
				return false
	return true

func _on_timer_timeout():
	win_check()
	fin_pos_e()

func win_check():
	var win = true
	var loss = true
	for u in units:
		if u.hp > 0:
			loss = false
	for u in enem_units:
		if u.hp > 0:
			win = false
	if win:
		get_tree().change_scene_to_file("res://win.tscn")
	if loss:
		get_tree().change_scene_to_file("res://lose.tscn")
