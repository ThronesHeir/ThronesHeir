extends CharacterBody2D

func _physics_process(delta):
	move_and_slide()

func arch(where_to: Vector2):
	pass
