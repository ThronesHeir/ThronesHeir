extends Area2D

var special
@onready var anim = $AnimationPlayer
@onready var sprite = $Sprite2D

func _ready():
	special = get_tree().get_first_node_in_group("special")
	$Sprite2D.position.y -= 40

func sp_atk() -> void:
	for u in self.get_overlapping_bodies():
		if u is enem_unit:
			u.hp -= 30
			u.atk -= 4
			u.speed -= 40

func sp_movement():
	$Sprite2D.position.y += 40
