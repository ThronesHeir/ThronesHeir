extends Camera2D

var MousePos = Vector2()
var MousePosGB = Vector2()
var Start = Vector2()
var StartV = Vector2()
var End = Vector2()
var EndV = Vector2()
var Dragging = false
signal area_selection
@onready var box = get_node("../UI/Panel")

func _ready():
	connect("area_selection", Callable(get_parent(), "on_area_selection"))

func _process(_delta) -> void:
		if Input.is_action_just_pressed("LMB"):
			Start = MousePosGB
			StartV = MousePos
			Dragging = true
		if Dragging:
			End = MousePosGB
			EndV = MousePos
			draw_area()
		
		if Input.is_action_just_released("LMB"):
			if StartV.distance_to(MousePos) > 20:
				End = MousePosGB
				EndV = MousePos
				Dragging = false
				draw_area(false)
				emit_signal("area_selection", self)
			else:
				End = Start
				Dragging = false
				draw_area(false)

func _input(event) -> void:
	if event is InputEventMouse:
		MousePos = event.position
		MousePosGB = get_global_mouse_position()

func draw_area(s = true) -> void:
	box.size = Vector2(abs(StartV.x - EndV.x), abs(StartV.y - EndV.y))
	var pos = Vector2()
	pos.x = min(StartV.x, EndV.x)
	pos.y = min(StartV.y, EndV.y)
	box.position = pos
	box.size *= int(s)
