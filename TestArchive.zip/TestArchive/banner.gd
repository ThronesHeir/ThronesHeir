class_name banner
extends Area2D

var player_stats
var unit_arr
@onready var sprite = $Sprite2D as Sprite2D

#Method used when the node has entered the scene
func _ready():
	self.visible = false
	self.position.x = -10000
	player_stats = get_tree().get_first_node_in_group("player_stats")
	sprite.scale.x = 0.5
	sprite.scale.y = 0.5
	

func sprite_choice():
	if player_stats.dictAB[self].fin_arr[0] is player_infantry:
		sprite.texture = preload("res://p_inf_banner.png")
	if player_stats.dictAB[self].fin_arr[0] is player_archer:
		sprite.scale.x = 0.3
		sprite.scale.y = 0.3
		sprite.texture = preload("res://p_arch_banner.png")
	if player_stats.dictAB[self].fin_arr[0] is player_cav:
		sprite.texture = preload("res://p_cav_banner.png")
		sprite.scale.x = 0.3
		sprite.scale.y = 0.3
	if player_stats.dictAB[self].fin_arr[0] is player_leader:
		sprite.texture = preload("res://p_lead_banner.png")

#Method called on every process frame
func _process(_delta) -> void:
	sprite_choice()
	self.position.x = Formation.get_avrg_pos(Formation.units_to_vec2(player_stats.dictAB[self].fin_arr)).x
	self.position.y = Formation.get_avrg_pos(Formation.units_to_vec2(player_stats.dictAB[self].fin_arr)).y - 50

#Method called when LMB has been pressed on the object itself
func _on_input_event(_viewport, _event, _shape_idx) -> void:
	if Input.is_action_just_pressed("LMB") and (Glb.curr_game_state != Glb.game_state.BATTLE or Glb.curr_game_state != Glb.game_state.PAUSED):
		unit_arr = player_stats.dictAB[self].fin_arr
		for unit: player_unit in unit_arr:
			if unit.selected == false and unit.hp > 0:
				unit.set_selected(true)
