class_name player_archer
extends player_unit

