class_name  player_infantry
extends player_unit

