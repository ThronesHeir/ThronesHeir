class_name player_leader
extends player_unit

