class_name player_cav
extends player_unit

