class_name player_unit
extends CharacterBody2D

#Variables related to the basic functions of the unit
@export var selected = false
@export var u_class: String
@onready var box = get_node("Box")
@onready var nav_agent := $NavigationAgent2D as NavigationAgent2D
@onready var target = position
@onready var world = get_tree().get_first_node_in_group("World")
@onready var area_detection = $Area2D as Area2D
@onready var anim = $AnimationPlayer as AnimationPlayer
@onready var sprite = $Sprite2D as Sprite2D
var enem_target: enem_unit
var followCursor = false

#Signals used for methods outside the node and in it
signal arrow_up
signal arrow_down
signal Attack
signal Walk
signal Idle
signal Dead

#Variables related to the units stats
@export var atk: int = 8
@export var speed: int = 100
@export var hp: int = 100

#Variable and enumerator
var curr_state
enum state {
	IDLE,
	ATTACK,
	WALKING,
	DEAD
}

#Method ready containing different variables and methods such as connecting the signals related to the designated methods
func _ready():
	self.set_process(false)
	self.set_physics_process(false)
	enem_target = null
	target = null
	set_selected(selected)
	connect("arrow_up", Callable(world, "arrow_up"))
	connect("arrow_down", Callable(world, "arrow_down"))
	connect("Attack", Callable(self, "switch_to_atk"))
	connect("Walk", Callable(self, "switch_to_walk"))
	connect("Dead", Callable(self, "switch_to_dead"))
	connect("Idle", Callable(self, "switch_to_idle"))


func set_selected(value) -> void:
	selected = value
	box.visible = value
	if value == false:
		emit_signal("arrow_down")
	if value == true:
		emit_signal("arrow_up")

func _physics_process(_delta):
	print(enem_target)
	flip_check()
	action()

func action() -> void:
	if curr_state == state.IDLE:
		anim_idle()
		idle()
		body_detection()
	if curr_state == state.WALKING:
		anim_walk()
		body_detection()
		movement()
	if curr_state == state.ATTACK:
		anim_atk()
		attack()
		movement()
		body_detection()
	if curr_state == state.DEAD:
		death()

func idle():
	if hp <= 0:
		emit_signal("Dead")
	elif target != null and enem_target != null:
		emit_signal("Attack")
	elif target != null and enem_target == null:
		emit_signal("Walk")

func movement() -> void:
		nav_agent.target_position = target
		var next_pos = nav_agent.get_next_path_position()
		var dir = global_position.direction_to(next_pos) * speed
		if hp <= 0:
			emit_signal("Dead")
		elif nav_agent.is_target_reached() == false and nav_agent.target_position != null:
			velocity = dir
			move_and_slide()
		elif nav_agent.is_target_reached() and enem_target == null:
			target = null
			emit_signal("Idle")

func death() -> void:
	self.visible = false
	set_selected(false)
	self.set_collision_layer_value(1, false)
	self.rotation_degrees = 90
	self.set_physics_process(false)
	self.set_process(false)

func attack() -> void:
	if hp < 0:
		emit_signal("Dead")
	if enem_target != null:
		if enem_target.hp > 0:
			enem_target.hp -= atk
		if enem_target.hp <= 0 or enem_target.curr_state == state.DEAD:
			enem_target = null
			emit_signal("Idle")

func body_detection() -> void:
	if enem_target == null:
		for u in area_detection.get_overlapping_bodies():
			if u is enem_unit:
				target = u.position
				enem_target = u
				emit_signal("Attack")
				return
	if enem_target != null:
		if self.position.distance_to(enem_target.position) > 120:
			enem_target = null

func anim_idle():
		if anim.is_playing() and anim.current_animation == "p_" + u_class + "_idle":
			pass
		elif anim.is_playing() == false and anim.current_animation != "p_" + u_class + "_idle":
			anim.play("p_" + u_class + "_idle")
		elif anim.is_playing() == false:
			anim.play("p_" + u_class + "_idle")

func anim_atk():
		if anim.is_playing() and anim.current_animation == "p_" + u_class + "_atk":
			pass
		elif anim.is_playing() == false and anim.current_animation != "p_" + u_class + "_atk":
			anim.play("p_" + u_class + "_atk")
		elif anim.is_playing() == false:
			anim.play("p_" + u_class + "_atk")

func anim_walk():
		if anim.is_playing() and anim.current_animation == "p_" + u_class + "_walk":
			pass
		elif anim.is_playing() == false and anim.current_animation != "p_" + u_class + "_walk":
			anim.play("p_" + u_class + "_walk")
		elif anim.is_playing() == false:
			anim.play("p_" + u_class + "_walk")

func flip_check():
	if target != null:
		if target.x < self.position.x:
			sprite.flip_h = true
		else:
			sprite.flip_h = false

func damage_done():
	if enem_target.hp > 0:
		enem_target.hp -= atk

func switch_to_atk() -> void:
	curr_state = state.ATTACK

func switch_to_idle() -> void:
	curr_state = state.IDLE

func switch_to_walk() -> void:
	curr_state = state.WALKING

func switch_to_dead() -> void:
	curr_state = state.DEAD
