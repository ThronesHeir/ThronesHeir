class_name enem_banner
extends banner

var enem_stats

#Method used when the node has entered the scene
func _ready():
	enem_stats = get_tree().get_first_node_in_group("enem_stats")

func _process(_delta):
	sprite_choice()
	self.position.x = Formation.get_avrg_pos(Formation.units_to_vec2(enem_stats.dictAB[self].fin_arr)).x
	self.position.y = Formation.get_avrg_pos(Formation.units_to_vec2(enem_stats.dictAB[self].fin_arr)).y - 50

func _on_input_event(_viewport, _event, _shape_idx):
	pass

func sprite_choice():
	if enem_stats.dictAB[self].fin_arr[0] is enem_infantry:
		sprite.texture = preload("res://e_inf_banner.png")
	if enem_stats.dictAB[self].fin_arr[0] is enem_archer:
		sprite.texture = preload("res://e_arch_banner.png")
	if enem_stats.dictAB[self].fin_arr[0] is enem_cav:
		sprite.texture = preload("res://e_cav_banner.png")
	if enem_stats.dictAB[self].fin_arr[0] is enem_leader:
		sprite.texture = preload("res://e_lead_banner.png")
