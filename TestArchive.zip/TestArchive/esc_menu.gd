extends Control

var world

func _ready():
	world = get_tree().get_first_node_in_group("World")
	self.set_process_input(false)

func _on_options_gui_input(event):
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		world.options.visible = true
		world.options.set_process_input(true)
		self.visible = false

func _on_back_to_game_gui_input(event):
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		self.visible = false
		if Glb.curr_game_state != Glb.game_state.BEGGINING:
			Glb.battle()

func _on_exit_gui_input(event):
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		get_tree().quit()
